
function mensagem() {
   
    var msn = "BackEnd";
    return msn
    
}

var msn1 = mensagem()

console.log(msn1);
