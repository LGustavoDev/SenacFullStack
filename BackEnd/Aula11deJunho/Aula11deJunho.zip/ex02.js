function receba(msn) {
    console.log(msn)

}

receba('BackEnd é um pouco DIFICÍL')
