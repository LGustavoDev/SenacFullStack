
function mensagem(mensagem) {

    console.log("Hello World");
    
}

mensagem()


